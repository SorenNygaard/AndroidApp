package com.example.projekt;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

/**
 * DatabaseManager is a utility class that manages interactions with the Firebase Realtime Database.
 * It provides methods for initializing the database, reading and writing data, and searching for books.
 */
public class DatabaseManager {

    private static DatabaseReference databaseReference;

    /**
     * Initializes the Firebase Realtime Database reference.
     */
    public static void initialize() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference();
    }

    /**
     * Gets the Firebase database reference.
     *
     * @return The database reference.
     */
    public static DatabaseReference getDatabaseReference() {
        return databaseReference;
    }

    /**
     * Gets the current user's ID.
     *
     * @return The current user's ID, or null if no user is signed in.
     */
    public static String getCurrentUserId() {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            return currentUser.getUid();
        }
        return null; // Return null if no user is signed in
    }

    /**
     * Reads data from the specified child node in the Firebase database.
     *
     * @param child              The child node to read from.
     * @param valueEventListener The listener to handle the data read event.
     */
    public static void readData(String child, ValueEventListener valueEventListener) {
        databaseReference.child(child).addListenerForSingleValueEvent(valueEventListener);
    }

    /**
     * Writes data to the specified child node in the Firebase database.
     *
     * @param child   The child node to write to.
     * @param data    The data to write.
     * @param context The context for showing toast messages.
     */
    public static void writeData(String child, Object data, Context context) {
        DatabaseReference newChildRef = databaseReference.child(child).push();
        newChildRef.setValue(data)
                .addOnSuccessListener(aVoid -> {
                    Log.d("DatabaseManager", "Data successfully written to the database");
                    Toast.makeText(context, "Book added successfully", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Log.e("DatabaseManager", "Error writing data to the database", e);
                    Toast.makeText(context, "Failed to add book: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    /**
     * Searches for books in the specified child node of the Firebase database.
     * The search is case-insensitive and matches books whose title starts with the query string.
     *
     * @param child              The child node to search in.
     * @param query              The search query.
     * @param valueEventListener The listener to handle the search result.
     */
    public static void searchBooks(String child, String query, ValueEventListener valueEventListener) {
        // Convert the query to lowercase for case-insensitive search
        String lowercaseQuery = query.toLowerCase();

        // Get the reference to the specified node in the Firebase Realtime Database
        DatabaseReference reference = databaseReference.child(child);

        // Construct the Firebase query for searching books by title
        Query searchQuery = reference.orderByChild("titel")
                .startAt(lowercaseQuery)
                .endAt(lowercaseQuery + "\uf8ff");

        // Add a ValueEventListener to the search query to handle the search result
        searchQuery.addListenerForSingleValueEvent(valueEventListener);
    }
}
